from imports import CURSOS_DISPONIVEIS

class Pessoa:
    def __init__(self, nome_completo: str, data_nascimento: str, curso: str):
        self.nome_completo = nome_completo
        self.data_nascimento = data_nascimento
        if curso in CURSOS_DISPONIVEIS:
            self.curso = curso
        else:
            raise ValueError(f"Curso '{curso}' não é válido.")

    def __str__(self):
        return f"{self.nome_completo}"
