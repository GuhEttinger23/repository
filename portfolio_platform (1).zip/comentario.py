from datetime import datetime

class Comentario:
    def __init__(self, autor, texto: str):
        self.autor = autor
        self.texto = texto
        self.data_hora = datetime.now()

    def __str__(self):
        timestamp = self.data_hora.strftime("%d/%m/%Y às %H:%M")
        nome_autor = getattr(self.autor, "nome_completo", "Usuário")
        return f'[{timestamp}] {nome_autor}: "{self.texto}"'
