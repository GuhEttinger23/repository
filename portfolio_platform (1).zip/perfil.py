from pessoa import Pessoa
from projeto import Projeto
from comentario import Comentario

class Perfil(Pessoa):
    def __init__(self, nome_completo: str, data_nascimento: str, curso: str):
        super().__init__(nome_completo, data_nascimento, curso)
        self.biografia = "Olá! Este é meu portfólio."
        self.projetos = []
        self.curtidos = []

    def definir_biografia(self, nova_bio: str):
        self.biografia = nova_bio
        print("✅ Biografia atualizada com sucesso!")

    def adicionar_projeto(self, titulo: str, descricao: str, link: str) -> Projeto:
        novo_projeto = Projeto(autor=self, titulo=titulo, descricao=descricao, link=link)
        self.projetos.append(novo_projeto)
        print(f"🚀 Novo projeto '{titulo}' adicionado ao seu portfólio!")
        return novo_projeto

    def curtir_projeto(self, projeto: Projeto):
        if projeto not in self.curtidos:
            projeto.receber_curtida()
            self.curtidos.append(projeto)
            print(f"❤️  Você curtiu o projeto '{projeto.titulo}'!")
        else:
            print(f"⚠️ Você já curtiu o projeto '{projeto.titulo}'.")

    def comentar_em_projeto(self, projeto: Projeto, texto_comentario: str):
        novo_comentario = Comentario(autor=self, texto=texto_comentario)
        projeto.adicionar_comentario(novo_comentario)

    def exibir_perfil_completo(self):
        print("\n" + "*"*10, f"PÁGINA DE PERFIL DE {self.nome_completo.upper()}", "*"*10)
        print(f"🎓 Curso: {self.curso}")
        print(f"ℹ️  Sobre: {self.biografia}")
        print("\n--- 📂 Meus Projetos ---")
        if self.projetos:
            for p in self.projetos:
                print(f"  - {p.titulo} ({p.curtidas} curtidas)")
        else:
            print("  (Nenhum projeto adicionado ainda)")

        print("\n--- ❤️ Meus Curtidos ---")
        if self.curtidos:
            for p in self.curtidos:
                print(f"  - {p.titulo} (de {p.autor.nome_completo})")
        else:
            print("  (Nenhum projeto curtido ainda)")
        print("*"*(34 + len(self.nome_completo)) + "\n")
