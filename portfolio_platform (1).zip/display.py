from perfil import Perfil

if __name__ == "__main__":
    print("🚀 BEM-VINDO À PLATAFORMA DE PORTFÓLIOS! 🚀")

    perfil_ana = Perfil("Ana Clara", "15/03/1998", "Programação Full Stack")
    perfil_bruno = Perfil("Bruno Silva", "22/07/2000", "Designer")

    perfil_ana.definir_biografia("Desenvolvedora apaixonada por Python e soluções criativas.")
    projeto_ana_1 = perfil_ana.adicionar_projeto(
        titulo="Sistema de Gerenciamento de Tarefas",
        descricao="Um app web feito com Flask para organizar tarefas diárias.",
        link="http://github.com/ana/tarefas"
    )
    projeto_ana_2 = perfil_ana.adicionar_projeto(
        titulo="Análise de Dados de Vendas",
        descricao="Um notebook Jupyter com análise de dados de vendas de uma loja.",
        link="http://github.com/ana/vendas"
    )

    projeto_bruno_1 = perfil_bruno.adicionar_projeto(
        titulo="Identidade Visual para Cafeteria",
        descricao="Criação de logo, paleta de cores e materiais gráficos.",
        link="http://behance.net/bruno/cafe"
    )

    print("\n" + "-"*50)
    print("🎬 AÇÃO: Bruno vai interagir com o projeto da Ana...")
    print("-"*50 + "\n")

    projeto_ana_1.exibir_detalhes()

    perfil_bruno.curtir_projeto(projeto_ana_1)
    perfil_bruno.comentar_em_projeto(projeto_ana_1, "Uau, Ana! Que projeto incrível! Muito bem estruturado.")

    perfil_ana.curtir_projeto(projeto_bruno_1)

    print("\n" + "-"*50)
    print("📊 RESULTADO FINAL: Vendo os perfis e projetos atualizados...")
    print("-"*50 + "\n")

    projeto_ana_1.exibir_detalhes()
    perfil_ana.exibir_perfil_completo()
    perfil_bruno.exibir_perfil_completo()
