CURSOS_DISPONIVEIS = [
    "Programação Full Stack",
    "Marketing",
    "Áudio Visual",
    "Designer",
    "Fotografia",
]

__all__ = ["CURSOS_DISPONIVEIS"]
