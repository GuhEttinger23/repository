class Projeto:
    def __init__(self, autor, titulo: str, descricao: str, link: str):
        self.autor = autor
        self.titulo = titulo
        self.descricao = descricao
        self.link = link
        self.comentarios = []
        self.curtidas = 0

    def adicionar_comentario(self, comentario):
        self.comentarios.append(comentario)
        print(f"💬 Novo comentário adicionado ao projeto '{self.titulo}'!")

    def receber_curtida(self):
        self.curtidas += 1

    def exibir_detalhes(self):
        print("\n" + "="*40)
        print(f"🎨 Projeto: {self.titulo.upper()}")
        print(f"✍️  Autor: {self.autor.nome_completo}")
        print(f"📋 Descrição: {self.descricao}")
        print(f"🔗 Link: {self.link}")
        print(f"❤️  Curtidas: {self.curtidas}")
        print("\n--- Comentários ---")
        if self.comentarios:
            for c in self.comentarios:
                print(f"  - {c}")
        else:
            print("  (Nenhum comentário ainda)")
        print("="*40 + "\n")
